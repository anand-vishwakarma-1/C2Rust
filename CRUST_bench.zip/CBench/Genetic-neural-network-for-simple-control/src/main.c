#include "genetic/population.h"
#include "general/matrix_math.h"
#include "general/sort.h"

#include <stdio.h>
#include <stdlib.h>
#include <time.h>



int main(){
  srand(time(0));
}