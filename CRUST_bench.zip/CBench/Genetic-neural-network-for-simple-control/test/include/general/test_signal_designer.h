#ifndef TEST_SIGNAL_DESIGNER_H
#define TEST_SIGNAL_DESIGNER_H

// function to test the creation of step signal
int testSignalCreate();

#endif