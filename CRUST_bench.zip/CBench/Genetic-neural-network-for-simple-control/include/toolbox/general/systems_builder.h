#ifndef SYSTEM_BUILDER_H
#define SYSTEM_BUILDER_H

int selectSystem(float (**func_ptr)(float*));

#endif