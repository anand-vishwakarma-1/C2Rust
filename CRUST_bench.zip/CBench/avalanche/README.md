For the post check out [Chartbeat Engineering](http://engineering.chartbeat.com/2014/08/13/you-dont-know-jack-about-hashing/)
