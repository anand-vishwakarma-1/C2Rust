#ifndef ACES_INTERNAL_TEST_H
#define ACES_INTERNAL_TEST_H

#ifdef __cplusplus
extern "C" {
#endif

int run_aces_internal_tests();

#ifdef __cplusplus
}
#endif

#endif
