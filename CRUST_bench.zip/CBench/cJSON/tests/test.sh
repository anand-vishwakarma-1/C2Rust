gcc test.c ../cJSON.c -o main
./main