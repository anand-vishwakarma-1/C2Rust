For security issues please inform the maintainer using Keybase encrypted message:

https://keybase.io/emadelsaid
